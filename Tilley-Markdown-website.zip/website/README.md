# Tilley Research Group website

The approved design with six separate pages, powered by Astro and Markdown. The opening video pauses off-screen; portraits load as you approach them. The published site uses ordinary static files. No database or server administration is needed.

## Everyday editing

| What to change | Where |
| --- | --- |
| A person's name, role, status, photo, or biography | `content/people/NAME.md` |
| A research topic | `content/research/TOPIC.md` |
| A publication | `content/publications/PAPER.md` |
| Main heading, introductory text, opportunities, contact details | `content/sections/*.md` |
| A portrait | `public/people/` |
| Opening video | `public/media/lab.webm` |

The block between `---` lines holds fields. Text below it is ordinary Markdown. Use quotes around titles or names containing punctuation, particularly colons. Keep `order` as a number and `draft` as `true` or `false` without quotes.

### Add someone

1. Copy `templates/person.md` into `content/people/`, for example `alex-smith.md`.
2. Upload a compressed portrait into `public/people/`, for example `alex-smith.webp`. Around 320 × 400 pixels is sufficient for this design.
3. Edit the Markdown fields. Use `photo: people/alex-smith.webp` — omit `public/` and the leading slash.
4. Set `draft: false` when ready. Save both files.

```yaml
---
name: "Alex Smith"
role: postdoc
status: current
photo: people/alex-smith.webp
order: 20
draft: false
---

Optional short biography.
```

Roles: `group-leader`, `postdoc`, `phd`, `msc`, `technician`.
Lower `order` numbers appear first within the role. Equal orders use filename order.
The photo and email fields are optional; remove either line if not available.

### Move someone to alumni

Change only `status: current` to `status: alumni`. Keep their role, file, and photo. After the next successful build, they leave the current-member grid and appear in the Alumni list under their former role. Alumni photos and biographies are retained in the source but not shown in this compact list. Restoring `status: current` brings the profile back.

### Publications and research

Copy the matching template into its content folder and edit the fields. Set `draft: false` to include it. Publications sort by year (newest first), then `order` (lowest first). Use `order` to arrange papers within a year. Research topics sort by `order`.

### General page text

Edit `content/sections/hero.md` for the opening heading; `research.md`, `team.md`, and `publications.md` for their introductions; `opportunities.md` for recruitment text and its link; and `contact.md` for the group name, address, email, phone, and footer note. Remove the `note` field when the design-preview label is no longer wanted. Markdown links, bold text, lists, and paragraphs work in section bodies.

## Run on your computer

Install Node.js 24 LTS and pnpm 11.19.0 (one-time setup). From this folder:

```sh
pnpm install
pnpm dev
```

Open the local address printed by Astro. Markdown edits update the local preview automatically. Stop it with Ctrl+C.

To produce the finished static site and a standalone preview:

```sh
pnpm build
pnpm offline
```

Open `offline/index.html` (or the existing `offline-preview.html` entry point). Keep the entire `offline/` folder together: it contains six linked HTML pages with embedded media. Each page works offline; email and DOI links need the appropriate application or internet connection. These files are snapshots: after editing Markdown, run the two commands again. `dist/` is generated output — edit the content files instead.

## Publish with GitHub Pages

This folder's contents must be at the repository root (the repository should contain `package.json`, `content/`, `src/`, and `.github/`, not a wrapping `website/` folder).

1. Create a repository owned by the group and upload these files, including the hidden `.github/` folder and `pnpm-lock.yaml`. Do not upload `node_modules/`, `.astro/`, or `dist/`.
2. Use a `main` branch. Under **Settings → Pages**, choose **GitHub Actions** as the source.
3. Push a change to `main`, or run **Build and publish website** from the Actions tab.
4. GitHub checks the content, rebuilds the page, and publishes it. If validation fails, the previous successful site stays online. The Actions log identifies the failed build.

The workflow reads the GitHub Pages address and repository path automatically, so portraits and video work under `username.github.io/repository/`. It also handles a custom domain configured in GitHub Pages. The existing domain has not been connected or changed; first review the temporary GitHub Pages site.

For a local build that mimics a project subpath:

```sh
BASE_PATH=/my-repository SITE_URL=https://example.github.io pnpm build
```

## Checks and maintenance

`pnpm test` checks the real build, member-to-alumni movement, adding a member, Markdown rendering, draft exclusion, invalid-field rejection, missing-photo rejection, and media paths under a repository subpath. `pnpm build` also validates content fields and referenced media files.

Dependencies are pinned in the manifest and lockfile. Update deliberately and run the checks afterward.

The initial content was migrated from the approved mockup. It contains 17 current members, the 10 former postdocs already listed in that mockup, and 3 selected publications. It is not a complete historical alumni or publication database. Review names, roles, and publication metadata with the group before public launch. The compressed photos and opening video came from the existing group website. The video is cropped to 1440 × 690 pixels to remove the bottom caption at all screen sizes; it is encoded at 24 fps without audio to reduce file size.

## Files for future development

- `src/components/SitePage.astro`: shared design, navigation, and content grouping.
- `src/pages/index.astro` and `src/pages/[page].astro`: Home and five section routes.
- `src/content.config.ts`: allowed fields and validation rules.
- `src/styles/site.css`: approved visual styling.
- `.github/workflows/deploy.yml`: checks and GitHub Pages publishing.
- `scripts/export-offline.mjs`: linked offline-page export.

No GitHub repository has been created and nothing has been deployed by this preparation step.

## Page structure

Home contains the opening video, the first three research topics, David’s portrait and people highlights, the latest three publications (sorted by year and order), and Opportunities and Contact previews. Edit `content/sections/home-team.md` to replace the highlights placeholder. Research, Team (including Alumni), Publications, Opportunities, and Contact each have a separate page. All use the same navigation and visual style. Markdown filenames and status workflows are unchanged. The video loads only on Home; David’s portrait appears on Home; the full portrait grid loads on Team.

## News and homepage highlights

Copy `templates/news.md` into `content/news/`. Set a quoted `date` (YYYY-MM-DD), title, and short summary; put the full article below the fields. Set `draft: false` to display it. News appears newest first; the latest entry automatically becomes the homepage people highlight. The initial three entries are explicitly labelled samples: replace their content and set `sample: false` before launch. `content/sections/news.md` controls the News page heading. `content/sections/home-team.md` still controls the highlights heading; its body is replaced by news entries.
