---
name: "Anina Portmann"
role: "phd"
status: "current"
photo: "people/anina-portmann.webp"
order: 7
draft: false
---


