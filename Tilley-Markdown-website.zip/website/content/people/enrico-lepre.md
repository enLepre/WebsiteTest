---
name: "Enrico Lepre"
role: "postdoc"
status: "current"
photo: "people/enrico-lepre.webp"
order: 3
draft: false
---


