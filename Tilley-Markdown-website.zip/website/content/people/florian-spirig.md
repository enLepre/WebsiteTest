---
name: "Florian Spirig"
role: "msc"
status: "current"
photo: "people/florian-spirig.webp"
order: 16
draft: false
---


