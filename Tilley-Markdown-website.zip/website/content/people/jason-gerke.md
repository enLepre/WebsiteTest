---
name: "Jason Gerke"
role: "phd"
status: "current"
photo: "people/jason-gerke.webp"
order: 9
draft: false
---


