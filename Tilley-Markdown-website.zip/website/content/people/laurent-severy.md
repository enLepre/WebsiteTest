---
name: "Laurent Sévery"
role: "postdoc"
status: "alumni"
order: 8
draft: false
---


