---
name: "Magdalena Marszałek"
role: "postdoc"
status: "alumni"
order: 3
draft: false
---


