---
name: "Pardis Adams"
role: "postdoc"
status: "current"
photo: "people/pardis-adams.webp"
order: 5
draft: false
---


