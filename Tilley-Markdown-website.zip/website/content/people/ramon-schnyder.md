---
name: "Ramon Schnyder"
role: "phd"
status: "current"
photo: "people/ramon-schnyder.webp"
order: 11
draft: false
---


