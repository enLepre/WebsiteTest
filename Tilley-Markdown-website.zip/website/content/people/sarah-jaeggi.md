---
name: "Sarah Jaeggi"
role: "phd"
status: "current"
photo: "people/sarah-jaeggi.webp"
order: 12
draft: false
---


