---
title: "Beyond Hole Transportation: Substrate-Engineered Sb₂Se₃ Photocathodes"
year: 2026
journal: "ACS Energy Letters · 11, 2915–2923"
doi: "https://doi.org/10.1021/acsenergylett.5c04281"
order: 2
draft: false
---


