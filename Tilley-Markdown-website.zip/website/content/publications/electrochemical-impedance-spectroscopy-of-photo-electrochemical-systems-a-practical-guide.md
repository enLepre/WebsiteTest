---
title: "Electrochemical Impedance Spectroscopy of (Photo)electrochemical Systems: A Practical Guide"
year: 2026
journal: "ACS Measurement Science Au"
doi: "https://doi.org/10.1021/acsmeasuresciau.6c00109"
order: 1
draft: false
---


