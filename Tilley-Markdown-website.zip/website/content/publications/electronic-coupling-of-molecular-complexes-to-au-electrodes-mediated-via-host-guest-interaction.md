---
title: "Electronic Coupling of Molecular Complexes to Au Electrodes Mediated via Host-Guest Interactions"
year: 2026
journal: "Journal of the American Chemical Society · 148, 330–339"
doi: "https://doi.org/10.1021/jacs.5c12957"
order: 3
draft: false
---


