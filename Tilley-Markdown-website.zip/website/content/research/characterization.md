---
title: "Characterization"
order: 3
draft: false
---

Understanding the processes that control materials performance.
