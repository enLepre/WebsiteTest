import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';

const pages = ['home', 'research', 'team', 'news', 'publications', 'opportunities', 'contact'];
await mkdir('offline', { recursive: true });
for (const page of pages) {
  let html = await readFile(page === 'home' ? 'dist/index.html' : `dist/${page}/index.html`, 'utf8');
  // Derive the deployment prefix from the home navigation link.
  const homeHref = html.match(/<a[^>]*class="brand"[^>]*href="([^"]+)"/)?.[1];
  if (!homeHref) throw new Error('Cannot locate home link in generated page');
  for (const id of pages) {
    const url = `${homeHref}${id === 'home' ? '' : id + '/'}`;
    html = html.split(`href="${url}"`).join(`href="${id === 'home' ? 'index' : id}.html"`);
  }
  for (const source of new Set([...html.matchAll(/src="([^"]+)"/g)].map(m => m[1]))) {
    const match = source.match(/(?:^|\/)((?:people|media)\/[a-zA-Z0-9_.\/-]+)$/);
    if (!match) continue;
    const path = match[1];
    if (path.split('/').includes('..')) throw new Error(`Invalid media path: ${path}`);
    const types = {webp:'image/webp',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webm:'video/webm',mp4:'video/mp4'};
    const mime = types[path.split('.').pop()];
    if (!mime) throw new Error(`Unsupported offline asset: ${path}`);
    const bytes = await readFile(resolve('dist', path));
    html = html.split(`src="${source}"`).join(`src="data:${mime};base64,${bytes.toString('base64')}"`);
  }
  await writeFile(`offline/${page === 'home' ? 'index' : page}.html`, html);
  if (page === 'home') {
    // Keep the user's existing preview link usable.
    const legacy = html.replace(/href="(index|research|team|news|publications|opportunities|contact)\.html"/g, 'href="offline/$1.html"');
    await writeFile('offline-preview.html', legacy);
  }
}
console.log('Saved seven offline pages. Open offline/index.html; keep the folder together.');
