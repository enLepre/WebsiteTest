---
title: "Your news title"
date: "2026-09-15"
summary: "A short summary for the homepage."
sample: false
draft: true
---

Full news text goes here.
