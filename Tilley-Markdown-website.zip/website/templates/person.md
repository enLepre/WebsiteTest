---
name: "New member"
role: postdoc
status: current
photo: people/new-member.webp
order: 100
draft: true
---

Optional short biography. Delete this text to show only the name and photo.
