---
title: "Publication title"
year: 2026
journal: "Journal · volume, pages"
doi: "https://doi.org/10.0000/replace-this"
order: 1
draft: true
---

Optional short note.
