import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, cp, symlink, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

test('Markdown updates drive the real static build', async t => {
  const root = resolve('.');
  const fixture = await mkdtemp(join(tmpdir(), 'tilley-content-test-'));
  try {
    for (const name of ['src', 'content', 'astro.config.mjs', 'package.json', 'tsconfig.json']) {
      await cp(join(root, name), join(fixture, name), { recursive: true });
    }
    await symlink(join(root, 'node_modules'), join(fixture, 'node_modules'), 'dir');
    await cp(join(root, 'public'), join(fixture, 'public'), { recursive: true });
    // Controlled test profiles: ordinary edits to the real roster must not break tests.
    await rm(join(fixture, 'content/people'), { recursive: true });
    await mkdir(join(fixture, 'content/people'));
    await mkdir(join(fixture, 'public/people'), { recursive: true });
    await writeFile(join(fixture, 'public/people/test.png'), Buffer.from(
      'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=', 'base64'));
    await writeFile(join(fixture, 'content/people/test-current.md'),
      '---\nname: "Fixture Current"\nrole: postdoc\nstatus: "current"\nphoto: people/test.png\n---\n');
    await writeFile(join(fixture, 'content/people/test-alumni.md'),
      '---\nname: "Fixture Alumni"\nrole: postdoc\nstatus: alumni\n---\n');
    function build() {
      return spawnSync(process.execPath, [join(root, 'node_modules/astro/bin/astro.mjs'), 'build'], {
        cwd: fixture,
        env: { ...process.env, ASTRO_TELEMETRY_DISABLED: '1', SITE_URL: 'https://example.github.io', BASE_PATH: '/test-repository' },
        encoding: 'utf8', timeout: 90000,
      });
    }
    function successful(result) { assert.equal(result.status, 0, result.stdout + result.stderr); }
    const page = () => readFile(join(fixture, 'dist/team/index.html'), 'utf8');
    const personPath = join(fixture, 'content/people/test-current.md');
    const original = await readFile(personPath, 'utf8');

    await t.test('baseline has portraits and correct GitHub project media paths', async () => {
      successful(build());
      const html = await page();
      assert.equal((html.match(/<img\b/g) || []).length, 1);
      assert.match(html, /src="\/test-repository\/people\/test\.png"/);
      const home = await readFile(join(fixture, 'dist/index.html'), 'utf8');
      assert.match(home, /src="\/test-repository\/media\//);
      assert.doesNotMatch(html, /<video/);
      assert.doesNotMatch(home, /<img/);
      for (const id of ['research','team','publications','opportunities','contact']) {
        const route = await readFile(join(fixture, `dist/${id}/index.html`), 'utf8');
        assert.match(route, new RegExp(`href="/test-repository/${id}/" aria-current="page"`));
        assert.equal((route.match(/<h1[ >]/g) || []).length, 1);
      }
      assert.match(html, /<article[^>]*data-person="test-current"/);
      assert.match(html, /<li[^>]*data-person="test-alumni"/);
    });
    await t.test('status transition, new member, Markdown body, and draft exclusion', async () => {
      await writeFile(personPath, original.replace('status: "current"', 'status: "alumni"'));
      await writeFile(join(fixture, 'content/people/test-member.md'),
        '---\nname: "Test Member"\nrole: postdoc\nstatus: current\norder: 99\n---\n\nResearch in **solar fuels**.\n');
      await writeFile(join(fixture, 'content/people/test-draft.md'),
        '---\nname: "Unpublished Profile"\nrole: postdoc\nstatus: current\ndraft: true\n---\n');
      successful(build());
      const html = await page();
      assert.doesNotMatch(html, /<article[^>]*data-person="test-current"/);
      assert.match(html, /<li[^>]*data-person="test-current"/);
      assert.match(html, /<article[^>]*data-person="test-member"/);
      assert.match(html, /<strong>solar fuels<\/strong>/);
      assert.doesNotMatch(html, /Unpublished Profile/);
    });
    await t.test('typos in status fail validation', async () => {
      await writeFile(personPath, original.replace('status: "current"', 'status: "alumnni"'));
      const result = build();
      assert.notEqual(result.status, 0);
      assert.match(result.stdout + result.stderr, /status/);
    });
    await t.test('missing portrait fails before publication', async () => {
      await writeFile(personPath, original.replace('people/test.png', 'people/missing-photo.webp'));
      const result = build();
      assert.notEqual(result.status, 0);
      assert.match(result.stdout + result.stderr, /Missing asset: public\/people\/missing-photo.webp/);
    });
  } finally {
    // Only the disposable fixture created above is removed; source files stay untouched.
    await rm(fixture, { recursive: true, force: true });
  }
});
